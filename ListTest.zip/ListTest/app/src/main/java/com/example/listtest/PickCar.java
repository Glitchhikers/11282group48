package com.example.listtest;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;

public class PickCar extends AppCompatActivity {

    Spinner cars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_car);


        cars = findViewById(R.id.CarTrim);
        ArrayList<String[]> tempList = (ArrayList<String[]>) getIntent().getExtras().get("trims");

        ArrayList<String> trimList = new ArrayList<String>();
        for (String[] car : tempList){
            trimList.add(car[63] + " " + car[46] + " " + car[47] + " " + car[23] + "L");
        }

        ArrayAdapter<String> lists = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, trimList);
        lists.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cars.setAdapter(lists);


    }
}