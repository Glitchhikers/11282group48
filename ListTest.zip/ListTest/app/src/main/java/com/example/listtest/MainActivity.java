package com.example.listtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    Button nextScreen;
    EditText make,model,year;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nextScreen = (Button) findViewById(R.id.nextScreen);
        make = (EditText) findViewById(R.id.makeIn);
        model = (EditText) findViewById(R.id.modelIn);
        year = (EditText) findViewById(R.id.yearIn);

        nextScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (make.getText().length() == 0 || model.getText().length() == 0 || year.getText().length() == 0){
                    Toast notific = Toast.makeText(getApplicationContext() , "Some Fields Empty!", Toast.LENGTH_LONG);
                    notific.show();
                }
                else {
                    String makeText = make.getText().toString();
                    String modelText = model.getText().toString();
                    int yearText = Integer.parseInt(year.getText().toString());

                    Vector<String[]> temp = Car.androidSearchCar(makeText,yearText,modelText,MainActivity.this);

                    ArrayList<String[]> trims = new ArrayList<>( temp);
                    if (trims.isEmpty()){
                        Toast notific = Toast.makeText(getApplicationContext() , "No Cars Found!", Toast.LENGTH_LONG);
                        notific.show();
                    }
                    else{

                        Intent next = new Intent(MainActivity.this, PickCar.class);
                        next.putExtra("trims",trims);

                        startActivity(next);
                    }

                }
            }
        });
    }
}